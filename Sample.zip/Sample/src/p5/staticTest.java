package p5;

import java.util.Scanner;

public class staticTest extends Static {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  int i;
		  System.out.println("Enter option 1 or 2");
		Scanner s = new Scanner(System.in);
		i = s.nextInt();
      
		switch(i)
		{
			case 1 : 
				System.out.println("calculation of temperature");
				Static obj1 = new Static();
				obj1.fahrenheitToCelcius();
				System.out.println("The temperature in Celcius is "+tempC);
				break;
				
			case 2 :
				System.out.println("calculation of max number");
				Static obj2 = new Static();
				obj2.Max();
				System.out.println("The max number is "+max);
				break;
				
			default:
				System.out.println("invalid input");
				
		}
	}

}
