package p5;

public class TestShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Rectangle obj1 = new Rectangle();
		obj1.setcolor("blue");
		obj1.setwidth(10);
		obj1.setheight(50);
		obj1.setradius(4);
		System.out.println("The color of the rectangle is "+obj1.getcolor()+" the width is "+obj1.getwidth()+" the height is "+obj1.getheight());
		obj1.getAreaR();
		obj1.getperimeterR();
		System.out.println("The radius of the circle is "+obj1.getradius());
		obj1.getAreaC();
		obj1.getperimeterC();
	}

}
