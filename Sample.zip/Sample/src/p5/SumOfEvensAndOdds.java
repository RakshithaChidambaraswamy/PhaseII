package p5;


import java.util.Arrays;
import java.util.Scanner;


public class SumOfEvensAndOdds {
	
	//Function 
	public int[] getSumOfEvensAndOdds(int[] input, int j) {
		// Student code begins here
		//int x[] = new int[5];
		int sum[] = new int[2];
		int even =0;
		int odd = 0;
		for(int i =0;i<j;i++)
		{
			if(input[i]%2 == 0)
			{
				even+=input[i];
			}
			else {
				odd+=input[i];
			}
		}
		
		sum[0]=even;
		sum[1]=odd;
		return sum;
		
		// Student code ends here
	}

	public void printSumOfEvensAndOdds(int[] input, int j) {
		System.out.println(Arrays.toString(getSumOfEvensAndOdds(input, j)));
	}

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int j = scan.nextInt();
		System.out.println("enter the numbers");
		int input[] = new int[j];
		for(int i = 0;i<j;i++ )
		{
		input[i] = scan.nextInt();
		}
		try {
		//	int[] input = new int[args.length];
		//	for (int i = 0; i < input.length; i++) {
		//		input[i] = Integer.parseInt(args[i]);
		//	}

			SumOfEvensAndOdds obj = new SumOfEvensAndOdds();
			obj.printSumOfEvensAndOdds(input, j);
		} catch (NumberFormatException e) {
			System.out.println("Only numbers are allowed.");
		}

	}
}

