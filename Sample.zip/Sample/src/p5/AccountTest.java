package p5;

public class AccountTest 
{
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Account account1 = new Account(30, "Savings");
		account1.getaccountDetails();
		account1.depositAmount(500);
		account1.getaccountDetails();
		
		Account account2 = new Account(1000, "Current");
		account2.getaccountDetails();
		account2.depositAmount(2000);
		account2.getaccountDetails();
		
		
	}

}
