package p5;

public class te {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*System.out.println
		("Result: " + 2 + 3 +5);
		System.out.println
		("Result: " + 2 + 3 *5);
	}

		int i,j=3;
	     for(i=3;i<0;i--) { j++; }
	     switch(j) {
	     case (0) :   j=j+1;
	     case(1):    j=j+2;
	     break;
	     case (2) :   j=j+3;
	     break;
	     case (10) :  j=j+10;
	     break;
	     default :
	      break;
	 } 
	     System.out.println(j);
		String s1 = "test";
	     String s2 = new String("test");

	     if(s1 == s2)
	         System.out.println(1);
	     else
	         System.out.println(2);
	     if(s1.equals(s2))
	         System.out.println(3);
	     else
	         System.out.println(4);
		
		if( "Welcome".trim() == "Welcome".trim() )
			System.out.println("Equal");
			else
			System.out.println("Not Equal");
		
		int x= 2;
		 int y= 1;
		 for (int z = 0; z < 5; z++){
		  if (( ++x > 2 ) || (++y > 2)){
		   x++;
		 }}
		 System.out.println(x + " " + y);
		 
		 int i=1, j=1;
	        try {
	            i++; 
	            j--;
	            if(i/j > 1)
	                i++;
	        }
	        catch(ArithmeticException e) {
	            System.out.println(0);
	        }
	        catch(ArrayIndexOutOfBoundsException e) {
	            System.out.println(1);
	        }
	        catch(Exception e) {
	            System.out.println(2);
	        }
	        finally {
	            System.out.println(3);
	        }
	        System.out.println(4);
	        
	        String s1 = "India";
	        String s2 =s1;
	        String s3 = s1.equals(s2);
	        
	        String [][] array = new String[3][];
	        System.out.println(array[2][0].toString());*/
	        
	        int i = 257;
	        byte x = (byte)i;
	               System.out.println(x);
	}	}
