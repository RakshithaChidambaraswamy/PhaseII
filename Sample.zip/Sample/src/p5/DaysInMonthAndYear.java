package p5;

import java.util.Scanner;

public class DaysInMonthAndYear {

	
		
		public int getMaxDays(int month, int year) {
			// Student code begins here
			
			
			
			
			if(month == 01 || month ==03 || month == 05 || month == 07 || month == 8 || month ==10 ||month == 12)
			{
				System.out.println("The number of days in the month" +month+ "is 31");
				isleap(year);
			}
			else if(month == 04 || month ==06 || month == 9 || month == 11)
			{
				System.out.println("The number of days in the month" +month+ "is 30");
				isleap(year);
					}
			
					
			else if(month == 02 )
			{
				if(isleap(year))
			{
				System.out.println("The number of days in the month" +month+ "is 29");
				//isleap(year);
			}
				else 
				{	
					System.out.println("The number of days in the month" +month+ "is 28");
					//isleap(year);
								 		}
			}
			
			else
			{
				System.out.println("invalid details");
			}
			
			return 0;							
			// Student code ends here
		}		

		public void printMaxDays(int month, int year) {
			getMaxDays(month, year);
		}

		 public static boolean isleap(int year){
		 	if(year % 4 == 0)
		 	{
		 		System.out.println("The Year " +year+ "is a leap year");
		 		return true;
		 	}
		 	
		 	else
		 	{
		 	System.out.println("The Year " +year+ "is not a leap year");
		 	return false;
		 	}
		 	
		 }

		public static void main(String[] args) {

			/*if (args.length != 2) {
				System.out.println("Exactly 2 inputs required");
				return;
			}*/

			try {
				int num1, num2;
				//take input using scanner
				//call getmax(num1,num2)
				System.out.println("Enter the month and Year details in mm and yyyy format");
				
				Scanner scan = new Scanner(System.in);
				
				num1 = scan.nextInt();
				num2 = scan.nextInt();
			//	num1 = Integer.parseInt(args[0]);
			//	num2 = Integer.parseInt(args[1]);
				DaysInMonthAndYear obj = new DaysInMonthAndYear();
				obj.printMaxDays(num1, num2);
			} catch (NumberFormatException e) {
				System.out.println("Only integers allowed.");
			}
			
}
}
	

