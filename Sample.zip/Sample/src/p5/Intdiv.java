package p5;

import java.util.Scanner;

public class Intdiv {

	static int a;
	static int b;
		float result;
		public void IntegerDiv()
		{
			result = a/b;
			System.out.println("the quotient of "+a+" divided by"+b+"is"+result);
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
		IntegerDivision obj1 = new IntegerDivision();
		System.out.println("Enter 2 numbers");
		try {
			Scanner scan = new Scanner(System.in);
			a = scan.nextInt();
			b = scan.nextInt();
			if()
		}catch ()
	}

}
