package p5;

import java.util.Scanner;

public class Static {
	
 static	float tempF;
 static	double tempC;
 static int a;
 static int b;
 static int max;
	
	static  double fahrenheitToCelcius()
	{
	
		
		System.out.println("enter the temperature in Fahrenheit");
		Scanner scan = new Scanner(System.in);
		tempF = scan.nextFloat();
		
		tempC = (5.0/9.0)*(tempF - 32);
		
		return tempC;
		
	}
	
	static int Max()
	{
		
		
		System.out.println("Enter 2 numbers");
		Scanner scan = new Scanner(System.in);
		a = scan.nextInt();
		b = scan.nextInt();
		
		if(a==b)
		{
			System.out.println("Don't enter same numbers");
			
		}
		else if(a>b)
		{
			max=a;
			
		}
			
		else
		{
			max =b;
			
		}
			
		return max;
	}

}
