package p5;

public class Rectangle {

	private String color=null;
	private double width;
	private	double height;
	private double radius;
	
	public String getcolor()
	{
		return color;
	}
		public void setcolor(String c)
	{
		this.color = c;
	}
	public double getwidth()	
	{
		return width;
	}
	public void setwidth(double w)
	{
		this.width =w;
	}
    public double getheight()
    {
    	return height;
    }
    public void setheight(double h)
    {
    	this.height = h;
    }
    
    public void setradius(double r)
    {
    	this.radius =r;
    }
    public double getradius()
    {
    	return radius;
    }
    public void getAreaR()
    {
    	double Area=0;
    	Area = width*height;
    	System.out.println("The Area of the Rectangle is "+Area);
    	    	   	
    }
    
    public void getAreaC()
    {
    	double Area=0;
    	Area = 3.14*radius*radius;
    	System.out.println("The Area of the circle is "+Area);
    }
    
    public void getperimeterC()
    {
    	double perimeter =0;
    	perimeter = 2*(3.14*radius);
    	System.out.println("The perimeter of the circle is "+perimeter);
    }
    public void getperimeterR()
    {
    	double perimeter =0;
    	perimeter = 2*(width+height);
    	System.out.println("The perimeter of the Rectangle is "+perimeter);
    }
}

