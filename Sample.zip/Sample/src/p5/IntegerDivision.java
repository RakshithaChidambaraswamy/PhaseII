package p5;

import java.io.IOException;
import java.text.ParseException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class IntegerDivision {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=0;
		int b=0;
		float result;
			
		
		System.out.println("Enter 2 numbers");
		Scanner scan = new Scanner(System.in);
		try {
			
		a = scan.nextInt();
		b = scan.nextInt();
		scan.close();
		
		result = a/b;
		System.out.println("the quotient of "+a+" divided by"+b+"is"+result);
		}catch(InputMismatchException n)
		{
			System.out.println("A non-integer input was given");
		}			
				
		catch(ArithmeticException e) {
			System.out.println("Attempted to divide by zero");
				
		}
		catch(ParseExc p){
			System.out.println("2 inputs were not supplied");
			
		}
	}	
				
	}