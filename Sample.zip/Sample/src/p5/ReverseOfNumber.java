package p5;

import java.util.Scanner;

public class ReverseOfNumber 
{
	
	//Function
	public long reverse(long input) {
		// STUDENT CODE BEGINS HERE
		long sum = 0;
		while(input>0)
		{
				
		
		long rem = input%10;
		
		if(rem!=0) {
		sum = rem + sum*10;
		
		}
		input = input/10;
		}
	//	System.out.println(sum);
		
	
		String i="0234";
		int ij=0234;
		 i="1"+i;
		 int ik=Integer.parseInt(i)
;
		 
		
	
	
	 
	 while(input<0)
	 {
		 long rem = input %10;
			
			if(rem!=0) {
			sum = rem + sum*10;
			
			}
			input = input/10;
	 }
	// System.out.println(sum);	
		// STUDENT CODE ENDS HERE
	 return sum;
	}
	private void printInReverse(long input) {
		System.out.println(reverse(input));
	}

	public static void main(String[] args) {

		System.out.println("enter a number");
		Scanner scan = new Scanner(System.in);
		long input = scan.nextLong();
	//	if (args.length != 1) {
	//		System.out.println("Exactly 1 input required.");
	//		return;
	//	}
		
		//if(args[0].toUpperCase().endsWith("L")){
		//	args[0] = args[0].substring(0, args[0].length()-1);
			
		//}

		try {
			
			
			//long input = Long.parseLong(args[0]);
			ReverseOfNumber obj = new ReverseOfNumber();
			obj.printInReverse(input);
		} catch (NumberFormatException e) {
			System.out.println("Only integers allowed.");
		}
	}
}
