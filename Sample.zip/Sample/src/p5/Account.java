package p5;

import java.util.Scanner;

public class Account {

	int accountNo ;
	double accountbalance;
	String accountType;
    static int  accountCount= 12345;
    
   
	
	Account(double d,  String c)
	{
		
		this.accountbalance = d;
		this.accountType = c;
		this.accountNo =accountCount++;	
			}
	
	
	
	 void depositAmount(double balance)
	 {
		 	 
		 System.out.println("The deposited amount is "+balance);
		 this.accountbalance+=balance;
	 }
	 
	 void getaccountDetails()
	 {
		 System.out.println("For the accountNo "+accountNo+" the account balance is "+accountbalance+" the account type is "+accountType);
		 
	 }
	 
}
