package p1;

abstract class Animal
{
	public abstract void animalSound();
}

public class abstractEx extends Animal  {
	
	public void animalSound()
	{
		System.out.println("Woof");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Animal obj = new abstractEx();
		obj.animalSound();
	}

}
