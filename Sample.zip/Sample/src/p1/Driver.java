package p1;

public class Driver extends Car{
	
	String drivername;
	
	Driver(String dname, String cname, int cid)
	{
		super(cname, cid);
		this.drivername = dname;
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Driver obj1 = new Driver("rakshitha", "santro", 123);
		System.out.println(obj1.drivername+ " "+ obj1.carname+ " " +obj1.carid);
	}

}
