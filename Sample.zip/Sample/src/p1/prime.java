package p1;

public class prime {
	
	int num1;
	int num2;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
