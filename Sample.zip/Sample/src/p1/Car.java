package p1;

public class Car {
	
	String carname;
	int carid;
	
	Car(String cname, int cid)
	{
		this.carname = cname;
		this.carid = cid;
			}
    
}
