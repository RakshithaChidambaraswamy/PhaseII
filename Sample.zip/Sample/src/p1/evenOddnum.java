package p1;

import java.util.Scanner;

public class evenOddnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		
		System.out.println("enter a number");
		
		int i = scan.nextInt();
		
		if (i % 2 ==0)
		{
			System.out.println("number is even");
		
		}
		else 
		{
			System.out.println("number is odd");
		}
		
	}

}
