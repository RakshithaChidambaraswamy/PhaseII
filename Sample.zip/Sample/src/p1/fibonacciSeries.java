package p1;

public class fibonacciSeries {

	public static void main(String[] args)
	{
		int count =7, num1 =0, num2 =1;
		System.out.println("Fibonacci series for "+count+" numbers is");
		
		for (int i=1; i<=count; ++i)
		{
			System.out.println(num1+ " ");
			
			int sumofprev = num1 + num2;
			num1 = num2;
			num2 = sumofprev;
		}
	}
}
