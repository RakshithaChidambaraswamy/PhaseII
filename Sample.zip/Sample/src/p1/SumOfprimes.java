package p1;

import java.util.Scanner;

public class SumOfprimes 
{

	//Function
	int findSumOfPrimesBetween(int from, int to) {
		// Student code begins here
		if(from>to) {
			int c;
			c = from;
			from = to;
			to = c;
		}
		
		int sum =0;
		
		
		int  flag =1;
	    
	    for (int b = from;b<=to; b++)
	    {
	 for (int a = 2;a<=b/2; a++)
	 {
		 if(b%a ==0)
		 {
			 flag =0;
			 break;
		 }
		 else
		 {
			 flag =1;
		 }
	 }
	 
	 if(flag ==0) {
		 System.out.println("b is not a prime"+b);
	 }
	 if(flag ==1)
	 {
		 sum = sum+b;
		 System.out.println("b is a prime"+b);
		 
	 }
		
	    }	// Student code ends here
	    System.out.println("sum is"+sum);
	    return 0;
	}

	void printSumOfPrimes(int from, int to) {
		System.out.println(findSumOfPrimesBetween(from, to));
	}

	public static void main(String[] args) {

		

		try {
			int num1, num2;
			System.out.println("Enter the 2 numbers");
			
			Scanner scan = new Scanner(System.in);
			
			num1 = scan.nextInt();
			num2 = scan.nextInt();
			
			//if(args.length!=2){
	//			System.out.println("Exactly 2 inputs required.");
	//			return;
	//		}
			//num1 = Integer.parseInt(args[0]);
		//	num2 = Integer.parseInt(args[1]);
			
			SumOfprimes obj = new SumOfprimes();
			obj.printSumOfPrimes(num1, num2);
		} catch (NumberFormatException e) {
			System.out.println("Only integers allowed.");
		}
		
	}
}


	