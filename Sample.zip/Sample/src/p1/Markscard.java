package p1;

public class Markscard {
	
	int Maths;
	int Science;
	int social;
	int English;
	
	Markscard(int math, int science, int social, int english)
	{
		this.Maths = math;
		this.Science = science;
		this.social = social;
		this.English = english;
	}

}
