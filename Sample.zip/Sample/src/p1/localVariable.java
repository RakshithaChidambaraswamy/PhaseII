package p1;

public class localVariable {

	public String myVar ="instance variable";
	
	public void mymethod()
	{
		String myVar = "inside method";
		System.out.println(myVar);
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		localVariable lv = new localVariable();
		
		System.out.println("call the method");
		lv.mymethod();
		
		System.out.println(lv.myVar);
		
	}

}
