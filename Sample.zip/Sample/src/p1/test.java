package p1;

public class test{

byte b=127;//instance variable
short s=2500;
int a =50000;
long l=78000000;
float f=765.000f;
double d=6893.000;
char c='e';
boolean flag;

static int i=45;// class variable

public void display()
{
System.out.println(d);
System.out.println(i);
}

public static void main(String[] args)
{
int ak=67;
test firstpgm= new test();
System.out.println("Welcome");
//System.out.println(args[0]);
//System.out.println(args[1]);
firstpgm.display();
i=12;
System.out.println(firstpgm.c);
System.out.println(i);
}

}