package p1;

public class Child extends Parent{

	int j = 20;
	
	
	void display()
	{
		
		System.out.println(" from child");
		
	}
}
