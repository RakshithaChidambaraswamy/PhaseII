package p1;

public class Parent {

	int i = 10;
	
	
	void display()
	{
		System.out.println(" from parent");
	}
}
