package p1;

import java.util.Scanner;

public class areaTraingle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		
		System.out.println("enter the width of the triangle");
		
	 double width = scan.nextDouble();
		
		System.out.println("enter the hieght of the triangle");
		
		double height = scan.nextDouble();
		
		double area = (width*height)/2;
	
		System.out.println("area of the triabgle is "+area);
		
	}

}
