package p1;

public class arithmeticOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float i = 5;
		float j = 10;
		
		System.out.println("i + j is "+ (i + j));
		System.out.println("i - j is "+ (i - j));
		System.out.println("i * j is "+( i*j));
		System.out.println("i /j is " + (i/j));
		System.out.println("i % j is " +(i%j));
		
		
	}

}
