package p1;

import java.util.Scanner;

public class multiply {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		
		multiply m = new multiply();
		System.out.println("enter the first value");
		int a = input.nextInt();
		System.out.println("enter the second value to multiply");
		int b = input.nextInt();
		
		input.close();
		
		int product = a*b;
		
		System.out.println("the product of two numbers is "+product);
		
		
	}

}
