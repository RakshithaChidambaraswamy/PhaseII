package p1;

public class Teacher {
	
	private String designation = "Teacher";
	private String collegename = "SJBIT";
	
	public String getdesignation()
	{
		return designation = "princi";
	}
	
	protected void setdesignation(String designation)
	{
		this.designation = designation;
			}

	protected String getcollegename() {
		return collegename;
	}
   protected void setcollegename(String collegename)
   {
	   this.collegename = collegename;
	      }
   void does()
   {
	   System.out.println("teaching");
	   
   }
   }


