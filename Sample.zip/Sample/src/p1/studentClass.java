package p1;

public class studentClass {
	
	int rollnum;
	String name;
	
	Address stuaddr;
	
	Markscard stuscore;
	
	studentClass(int rn, String name, Address addr, Markscard score)
	{
		this.rollnum = rn;
		this.name = name;
		this.stuaddr = addr;
		this.stuscore = score;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Address obj1 = new Address(44, "blore", "karnataka", "india");
		Markscard obj3 = new Markscard(60, 70, 80, 90);
		studentClass obj2 = new studentClass(12, "rakshitha", obj1, obj3);
		System.out.println(obj2.rollnum);
		System.out.println(obj2.name);
		System.out.println(obj2.stuaddr.Streetnum);
		System.out.println(obj2.stuaddr.city);
		System.out.println(obj2.stuaddr.state);
		System.out.println(obj2.stuaddr.country);
		System.out.println(obj2.stuscore.Maths);
		System.out.println(obj2.stuscore.Science);
		System.out.println(obj2.stuscore.social);
		System.out.println(obj2.stuscore.English);
		
	}

}
