package p1;

public class physicsTeacher extends Teacher
{
	static String mainSubject = "Physics";
	
	public static void main(String args[])
	{
		physicsTeacher obj1 = new physicsTeacher();
		
		System.out.println(mainSubject);
		System.out.println(obj1.getdesignation());
		System.out.println(obj1.getcollegename());
		obj1.does();
		
	}
}