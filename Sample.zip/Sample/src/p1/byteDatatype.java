package p1;

public class byteDatatype {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		byte b;
		
		b = 127;
		
		System.out.println(b);
		
		short s = 32765;
		
		System.out.println(s);
		
		long l = -12342515L;
		
		System.out.println(l);
		
		double d = -123452643.8d;
		
		System.out.println(d);
		
		
		float f = 142.21f;
		
		System.out.println(f);
		
		boolean boo = false;
		
		System.out.println(boo);
		
		char c = 'e';
		
		System.out.println(c);
	}

}
