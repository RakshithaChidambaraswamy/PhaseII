package p1;

public class Testparentchild {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Parent obj1 = new Parent();
		
		obj1.display();
	}

}
