package p1;

class E1 {

	private int numofemp = 0;
	
	public void setnumofemp (int count)
	{
		numofemp = count;
		
	}
	
	public double getnumofemp ()
	
	{
		return numofemp;
		
	}
}
	public class EncapsulationEx
	{
		// TODO Auto-generated method stub
public static void main(String[] args)
{
	E1 obj1 = new E1();
	obj1.setnumofemp(444);
	System.out.println(" number of employess are " +(int)obj1.getnumofemp());
		
	}

}
