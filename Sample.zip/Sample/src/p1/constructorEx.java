package p1;

public class constructorEx {

	int age;
	String name;
	
	constructorEx()
	{
		
		this.age=28;
		this.name = "raks";
		
	}
	
	constructorEx(String n, int a)
	{
		this.name=n;
		this.age=a;
		
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		constructorEx obj1 = new constructorEx();
		constructorEx obj2 = new constructorEx("yash", 29);
		
		System.out.println(obj1.name+ " "+ obj1.age);
		System.out.println(obj2.name+ " "+ obj2.age);
	}

}
