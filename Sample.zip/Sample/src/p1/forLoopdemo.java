package p1;

public class forLoopdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = {1,3,4,6,8};
		
		for (int i : arr)
		{
			System.out.println(i);
		}
		String s[] = {"hi", "hello", "namaste"};
		
	for (String sr : s)
	{
		System.out.println(sr);
	}
	
	}
	

}
