package p1;

import java.util.Scanner;

public class ternaryOp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		
		System.out.println("enter first number");
		int a = scan.nextInt();
		
		System.out.println("enter second number");
		int b = scan.nextInt();
		
		System.out.println("enter thrid number");
		int c = scan.nextInt();
		
		scan.close();
		
		int result, temp;
		
		temp = a>b ? a:b;
		result = c > temp ? c : temp;
		
		System.out.println(" greatest number is "+result);
				
				
		
	}

}
