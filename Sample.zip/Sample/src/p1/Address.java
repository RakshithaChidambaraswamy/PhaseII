package p1;

public class Address {

	int Streetnum;
	String city;
	String state;
	String country;
	
	Address(int street, String city, String state, String country)
	{
		this.Streetnum = street;
		this.city = city;
		this.state = state;
		this.country = country;
		
	}
}
