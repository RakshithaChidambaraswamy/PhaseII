package p1;

public class statVariable {
	
	public static String myVar= "class or static variable";
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		statVariable obj1 = new statVariable();
		statVariable obj2 = new statVariable();
		statVariable obj3 = new statVariable();
		
		System.out.println(obj1.myVar);
		System.out.println(obj2.myVar);
		System.out.println(obj3.myVar);
		
		myVar = "changed text";
		
		System.out.println(myVar);
		System.out.println(obj2.myVar);
		System.out.println(obj3.myVar);
		
	}

}
