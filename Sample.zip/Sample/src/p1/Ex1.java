package p1;

public class Ex1 {
	
	static int i = 100;
	static String s = "rakshitha";
	
	static class Ex2
	{
		static void display()
		{
			System.out.println("i is"+i);
			System.out.println("s is"+s);
			
					
			}
		
		void fun()
		{
			display();
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Ex1.Ex2 obj1 = new Ex1.Ex2();
     obj1.display();
	}

}
