package p1;

public class instanceVariable {

	String instVar ="these are instance variable";
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		instanceVariable obj1 = new instanceVariable();
		instanceVariable obj2 = new instanceVariable();
		instanceVariable obj3 = new instanceVariable();
		
		System.out.println(obj1.instVar);
		System.out.println(obj2.instVar);
		System.out.println(obj3.instVar);
		
		obj2.instVar = "changed text";
		
		System.out.println(obj1.instVar);
		System.out.println(obj2.instVar);
		System.out.println(obj3.instVar);
		
	}

}
