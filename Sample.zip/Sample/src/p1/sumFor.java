package p1;

import java.util.Scanner;

public class sumFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		
		System.out.println("enter a number");
		
		int i =scan.nextInt(), count, total =0;
		
		for (count = 1; count <=i; count++)
		{
			total = total + count;
		}
		
		System.out.println("total is" +total );
	}

}
