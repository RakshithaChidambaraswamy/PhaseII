package p1;

class Teacher{
	String designation="Teacher";
	String collegename="SJBIT";
	
	void does()
	{
		System.out.println("Teaching");
		
	}
}

public class inheritEx extends Teacher{
	
	String mainsubject = "maths";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		inheritEx obj1 = new inheritEx();
		System.out.println(obj1.designation);
		System.out.println(obj1.collegename);
		System.out.println(obj1.mainsubject);
		obj1.does();
		
	}

}
