package p1;

public class Ascii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char ch ='P';
		int asciicode = ch;
		
		int asciivalue = (int)ch;
		
		System.out.println("Ascii value of "+ch+" is: " +asciicode);
		System.out.println("Ascii value of "+ch+" is: " +asciivalue);
				
	}

}
