package testselenium;



import java.awt.AWTException;
import java.awt.Desktop.Action;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestSel {

	public static void main(String[] args) throws InterruptedException, AWTException, IOException  {
		
		System.setProperty("webdriver.chrome.driver","C:\\Rakshitha\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
	/*	driver.get("https://www.facebook.com/");
	//	driver.findElement(By.id("identifierId")).sendKeys("raks");
        String title = driver.getTitle();
        System.out.println(title);
        String currenturl = driver.getCurrentUrl();
        System.out.println(currenturl);
        String source = driver.getPageSource();
        System.out.println(source);
        driver.close();
        
       System.setProperty("webdriver.gecko.driver","D:\\geckodriver-v0.26.0-win64\\geckodriver.exe");
        WebDriver driver = (WebDriver) new FirefoxDriver();
        driver.get("https://www.facebook.com/");
        String title = driver.getTitle();
        System.out.println(title);
        String url = driver.getCurrentUrl();
        System.out.println(url);
        String source = driver.getPageSource();
        System.out.println(source);
        driver.quit();
        
        driver.navigate().to("https://www.facebook.com/");
        driver.get("https://www.google.com/");
       driver.navigate().back();
       driver.navigate().forward();
     driver.navigate().refresh();
        String url = driver.getCurrentUrl();
        System.out.println(url);
        driver.findElement(By.id("u_0_m")).sendKeys("sel");
        driver.findElement(By.id("u_0_m")).clear();
        driver.quit();
		
		driver.navigate().to("https://www.facebook.com/");
		driver.findElement(By.id("u_0_6")).click();
		driver.findElement(By.id("u_0_13")).click();
		driver.findElement(By.linkText("Create a Page")).click();
        
		driver.navigate().to("https://www.facebook.com/");
		Boolean flag = driver.findElement(By.id("u_0_13")).isDisplayed();
		if(flag ==true)
			System.out.println("sign up button is displayed");
		else
			System.out.println("sign up button not displayed");
		
		boolean flag1 = driver.findElement(By.id("u_0_6")).isEnabled();
		if(flag1 ==true)
			System.out.println("radio button is enabled");
		else
			System.out.println("radio button not enabled");
		
		driver.navigate().to("https://www.facebook.com/");
		String text = driver.findElement(By.className("_58mt")).getText();
		System.out.println(text);
		
		String text1 = driver.findElement(By.className("_58mt")).getTagName();
		System.out.println(text1);
		
		driver.findElement(By.id("u_0_m")).sendKeys("raks");
		String attribute = driver.findElement(By.id("u_0_m")).getAttribute("name");
		System.out.println(attribute);
		
		 Dimension size = driver.findElement(By.id("u_0_m")).getSize();
		 System.out.println(size);
		
		driver.navigate().to("http://demo.guru99.com/test/ajax.html");
		List<WebElement> e = driver.findElements(By.name("name"));
		System.out.println("size is "+e.size());
		
		for(int i =0; i<e.size(); i++)
		 System.out.println("values are "+e.get(i).getAttribute("value"));
     	String s = e.get(i).getAttribute("value");
		
		driver.navigate().to("http://demo.guru99.com/test/radio.html");
		driver.findElement(By.id("vfb-7-1")).click();
		System.out.println("first is selected");
		driver.findElement(By.id("vfb-7-2")).click();
		System.out.println("second is selected");
		
		driver.navigate().to("http://demo.guru99.com/test/radio.html");
		driver.findElement(By.id("vfb-6-0")).click();
		boolean b = driver.findElement(By.id("vfb-6-0")).isSelected();
		if(b ==true)
		{
			System.out.println("first checkbox is selected");
		}
		else
		{
			System.out.println("first checkbox is not selected");
		
		}
		
	driver.navigate().to("http://demo.guru99.com/test/newtours/register.php");
		Select dropdwn = new Select(driver.findElement(By.name("country")));
		dropdwn.selectByVisibleText("INDIA");
		dropdwn.selectByValue("ANTARCTICA");
	dropdwn.selectByIndex(3);
		
		driver.get("http://output.jsbin.com/osebed/2");
		Select fruits = new Select(driver.findElement(By.id("fruits")));
		fruits.selectByVisibleText("Banana");
		fruits.selectByValue("orange");
		fruits.deselectByValue("orange");
		
		
		driver.get("https://www1.nseindia.com/live_market/dynaContent/live_analysis/top_gainers_losers.htm?cat=G");
		List<WebElement> col = driver.findElements(By.xpath("//table[@id = 'topGainers']/tbody/tr/th"));
		for(int i=0;i<col.size(); i++)
		{
			System.out.println(col.get(i).getText());
		}
		
	driver.get("https://www1.nseindia.com/live_market/dynaContent/live_analysis/top_gainers_losers.htm?cat=G");
	try {
		Thread.sleep(4000);
	}catch(InterruptedException e)
	{
		e.getStackTrace();
	}
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
	List<WebElement> col = driver.findElements(By.xpath("//table[@id = 'topGainers']/tbody/tr/td"));
	
	for(int i=0;i<col.size(); i++)
	{
		System.out.print(col.get(i).getText());
		
		driver.get("http://softwaretestingplace.blogspot.com/2017/02/selenium-fluent-wait.html");
			
		WebDriverWait wait = new WebDriverWait(driver, 4000);
		
		WebElement we = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Click Me - Fluent Wait')]")));
			we.click();	
	}
		
		driver.get("http://softwaretestingplace.blogspot.com/2017/02/selenium-fluent-wait.html");
		driver.findElement(By.xpath("//*[contains(text(),'Click Me - Fluent Wait')]")).click();
		
		
		FluentWait<WebDriver> wait = new FluentWait<>(driver)
		.withTimeout(Duration.ofSeconds(30))
		.pollingEvery(Duration.ofSeconds(3))
		.ignoring(NoSuchElementException.class);
		
		WebElement we = wait.until(new Function<WebDriver, WebElement>()
				{
			public WebElement apply(WebDriver driver)
			{
				WebElement element = driver.findElement(By.id("demo"));
				String gettext = element.getText();
			
				
	
	if(gettext.equals("Software Testing Material - DEMO PAGE"))
	{
		System.out.println(gettext);
		return element;
	}
	else
	{
		System.out.println("failed");
	    return null;
			}
				}
				});
				
				
		driver.get("https://www.guru99.com");
		
		driver.manage().window().maximize();
		Actions action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//td[@class = 'gsc-search-button']/following::button"));
		action.keyDown(Keys.SHIFT).sendKeys(we,"guru").keyUp(Keys.SHIFT).sendKeys(we,"99").build().perform();
		
		}
		
		
        driver.get("https://smallpdf.com/jpg-to-pdf");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[text()='Choose file']")).click();
		Robot robot = new Robot();
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		
		
		driver.get("https://www.guru99.com");
		driver.manage().window().maximize();
		
		Actions act = new Actions(driver);
		WebElement w = driver.findElement(By.xpath("//span[text() = 'Testing']"));
		WebElement j = driver.findElement(By.xpath("//span[@class ='g-menu-item-title' and text() = 'JUnit']"));
		act.moveToElement(w).click(j).build().perform();
		
		
		
		driver.get("https://www.guru99.com");
		driver.manage().window().maximize();
		Actions act = new Actions(driver);
		WebElement w = driver.findElement(By.xpath("//span[text() = 'Testing']"));
		WebElement j = driver.findElement(By.xpath("//span[@class ='g-menu-item-title' and text() = 'JUnit']"));
		act.contextClick(w).build().perform();
		
		
		driver.get("https://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		Actions act = new Actions(driver);
		driver.switchTo().frame(0);
		
		WebElement draga= driver.findElement(By.id("draggable"));
		WebElement dropp = driver.findElement(By.id("droppable"));
		act.dragAndDrop(draga, dropp).build().perform();
		
		driver.get("https://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		Actions act = new Actions(driver);
		driver.switchTo().frame(0);
		//click and hold
		WebElement draga= driver.findElement(By.id("draggable"));
		WebElement dropp = driver.findElement(By.id("droppable"));
		act.clickAndHold(draga).release(dropp).build().perform();
		
		
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		Robot r = new Robot();
		Dimension d = driver.findElement(By.xpath("//input[@name ='q']")).getSize();
		System.out.println(d.height);
		System.out.println(d.width);
		r.mouseMove(34, 387);
		r.mousePress(InputEvent.BUTTON1_MASK);
		r.mousePress(InputEvent.BUTTON3_DOWN_MASK);
		
		driver.get("https://www.inviul.com");
		driver.manage().window().maximize();
		WebElement we = driver.findElement(By.id("s"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('s').value ='selenium'");
		
		
		driver.get("https://www.inviul.com");
		driver.manage().window().maximize();
	    WebElement we = driver.findElement(By.xpath("//*[@id ='blog']"));
		WebElement wf = driver.findElement(By.id("s"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	    Thread.sleep(5000);
		js.executeScript("arguments[1].value ='selenium';", we, wf);
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", wf);
		Thread.sleep(5000);
		js.executeScript("alert('wow!!!')");
		Thread.sleep(5000);
		js.executeScript("history.go(0)");
		
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String url = js.executeScript("return document.title;").toString();
	    String url1 = js.executeScript("return document.domain;").toString();
		String url2 = js.executeScript("return document.URL;").toString();
		System.out.println(url);
	    System.out.println(url1);
	    System.out.println(url2);
		WebElement w = driver.findElement(By.xpath("//a[text() = 'Gmail']"));
		js.executeScript("arguments[0].click();",w);
		
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		driver.findElement(By.id("u_0_m")).sendKeys(cell);
		FileInputStream f = new FileInputStream("C:\\Rakshitha\\Samexcelselenium.xlsx");
		XSSFWorkbook w = new XSSFWorkbook(f);
		XSSFSheet s = w.getSheetAt(0);
		String r = s.getRow(0).getCell(0).getStringCellValue();
		System.out.println(r);
		int totalrows = s.getLastRowNum();
		System.out.println("totalrows is:"+totalrows);
		for(int i =0; i<=totalrows; i++)
		{
			r = s.getRow(i).getCell(0).getStringCellValue();
			System.out.println(r);
		}
		w.close();
		
		
		
		FileInputStream f = new FileInputStream("C:\\Rakshitha\\Samexcelselenium.xlsx");
		XSSFWorkbook w = new XSSFWorkbook(f);
		XSSFSheet s = w.getSheetAt(0);
		//s.getRow(0).getCell(0).setCellValue("value");
		Row row = s.createRow(10);
		Cell cell = row.createCell(10);
		cell.setCellValue("selenium");
		FileOutputStream o = new FileOutputStream("C:\\Rakshitha\\Samexcelselenium.xlsx");
		w.write(o);
		o.close();
		w.close();
		System.out.println(cell);
		
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
		FileInputStream f = new FileInputStream("C:\\Rakshitha\\Samexcelselenium.xlsx");
		XSSFWorkbook w = new XSSFWorkbook(f);
		XSSFSheet s = w.getSheetAt(0);
		String r = s.getRow(0).getCell(0).getStringCellValue();
		driver.findElement(By.id("u_0_m")).sendKeys(r);
		String r1 =s.getRow(0).getCell(1).getStringCellValue();
		driver.findElement(By.id("u_0_o")).sendKeys(r1);
		System.out.println("nameis :"+r+ "surname is: "+r1);
		w.close();

		
		driver.get("https://www.calculator.net/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("BMI Calculator")).click();
		Thread.sleep(3000);
		FileInputStream f = new FileInputStream("C:\\Rakshitha\\Samexcelselenium.xlsx");
		XSSFWorkbook w = new XSSFWorkbook(f);
		XSSFSheet s =w.getSheetAt(0);
		int age = (int) s.getRow(1).getCell(0).getNumericCellValue();
		Float weight = (float) s.getRow(1).getCell(1).getNumericCellValue();
		driver.findElement(By.id("cage")).clear();
		driver.findElement(By.id("cage")).sendKeys(String.valueOf(age));
		driver.findElement(By.id("cpound")).clear();
		driver.findElement(By.id("cpound")).sendKeys(String.valueOf(weight));
		driver.findElement(By.xpath("//*[@value = \"Calculate\"]")).click();
		
		String out = driver.findElement(By.xpath("//div[@class='bigtext']/b")).getText();
		
		FileOutputStream o = new FileOutputStream("C:\\Rakshitha\\output.xlsx");
		s.getRow(0).getCell(0).setCellValue(out);
		w.write(o);
		w.close();
		o.close();
		
		
	
		 driver.get("http://demo.guru99.com/test/delete_customer.php");            
                
	        driver.findElement(By.name("cusid")).sendKeys("53920");    
	        
	        driver.findElement(By.name("submit")).submit();            
	                
	        // Switching to Alert        
	        Alert alert = driver.switchTo().alert();        
	                
	        // Capturing alert message.    
	        String alertMessage= alert.getText();
	                
	        // Displaying alert message        
	        System.out.println(alertMessage);    
	        Thread.sleep(2000);
	                
	        // Accepting alert        
	        driver.switchTo().alert().dismiss();
	        Thread.sleep(6000);
		
		driver.get("http://demo.guru99.com/test/guru99home/");
		driver.manage().window().maximize();
		WebElement we =	driver.findElement(By.cssSelector("iframe[src='https:/www.youtube.com/embed/RbSlW8jZFe8']"));
		driver.switchTo().frame(we);
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("div.ytp-cued-thumbnail-overlay-image")).click();
				
		driver.get("http://www.naukri.com");
		driver.manage().window().maximize();
		String parent = driver.getWindowHandle();
		System.out.println(parent);
		Set<String> s1 = driver.getWindowHandles();
		int totalwindowsize = s1.size();
		System.out.println(totalwindowsize);
		for(String child_window:s1)
		{
			if(!parent.equals(child_window))
			{
				driver.switchTo().window(child_window);
				System.out.println(driver.switchTo().window(child_window).getTitle());
				driver.close();
				}
					}
		driver.switchTo().window(parent);*/

				
				
	
	
	driver.get("http://uniformm1.upskills.in/admin/");
	driver.manage().window().maximize();
	driver.findElement(By.id("input-username")).sendKeys("admin");
	driver.findElement(By.id("input-password")).sendKeys("admin@123");
	driver.findElement(By.xpath("//button[@type ='submit']")).click();
	driver.findElement(By.xpath("//a[@class='parent']/i[@class='fa fa-shopping-cart fa-fw']")).click();
	List<WebElement> obj = driver.findElements(By.xpath("//li[@id='sale']/ul/li"));
	
	String flag;
	for(int i=0;i<obj.size();i++)
	{
	WebElement element = obj.get(i);
	flag=obj.get(i).getText();
	if(flag.equals("Orders"))
	{
	element.click();
	Thread.sleep(10000);
	break;
	}
	}	
	
	driver.findElement(By.xpath("//td[@class='text-center']/input[@value='242']")).click();
	driver.navigate().to("http://uniformm1.upskills.in/admin/index.php?route=sale/order/edit&token=DUPv5zVJze9IxdpupiXFetixqqkZyM1l&order_id=242");
	driver.manage().window().maximize();
	driver.findElement(By.id("input-username")).sendKeys("admin");
	driver.findElement(By.id("input-password")).sendKeys("admin@123");
	driver.findElement(By.xpath("//button[@type ='submit']")).click();
	Thread.sleep(3000);
	driver.findElement(By.id("button-customer")).click();
	
			
}
}