package testselenium;


//Declare all packages 
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Page_Title_TestTest {

     public static void main(String args[]) {
    	 
    	 System.setProperty("webdriver.chrome.driver", "C:\\Rakshitha\\chromedriver_win32\\chromedriver.exe");
     WebDriver driver = new ChromeDriver();
     
     /* driver.get("https://www.gmail.com");
    
     driver.manage().window().maximize();
     
     driver.findElement(By.id("identifierId")).sendKeys("");
     
      driver.findElement(By.id("identifierNext")).click();
      
      driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);  
      
      driver.findElement(By.xpath("//input[@name='password']")).sendKeys("");
     
      driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
     
     driver.findElement(By.id("passwordNext")).click();
     
	  String Expected ="manzoormehadi26@gmail.com";
	  String Actual =// write your code to get link
	  assertEquals(Actual, Expected);*/
     
     driver.get("http://www.google.com");
     List <WebElement> list = driver.findElements(By.tagName("a"));
     System.out.println("Number of links: "+list.size());
     for(int i = 0; i < list.size(); i++){
     System.out.println(list.get(i).getText());
     }

}
}