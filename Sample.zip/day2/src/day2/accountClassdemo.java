package day2;

public class accountClassdemo {
	
	static int accountcount = 12500;
	
	private int accountid;
	private double accountbalance;
	private String accttype;
	
	public accountClassdemo()
	{
		System.out.println("welcome");
	}
	
	public accountClassdemo(double accountbalance, String accttype)
	{
		this.accountid=++accountcount;
		this.accountbalance;
	}
	
	public void displaydetails()
	{
		System.out.println("id"+accountid);
	}

	

}
