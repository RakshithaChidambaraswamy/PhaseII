package day2;

public class Day2 {

	public static void main (String[] args)
	{
		int a=4;
		long l=a;//implicit casting
		short s= (short)a;//explicit casting
		
		
		byte b =4;
		long ss=b*b;
		byte d= (byte) ss;
		int x=b;
		byte c=(byte) x;
		System.out.println((a % 2==0) ? "even": "false");
		System.out.println (c);
		System.out.println (d);
		System.out.println (ss);
	}
}
