package day2;

public class switchdemo {
	
	public static void main(String args[])
	{
		
		int a=2;
		
		switch (a)
		
		{
		case 0:
			
			System.out.println("zero");
			break;
			
		case 1:
			
			System.out.println("one");
			break;
			
		default :
			
			System.out.println("default");
			break;
			
		}
	}

}
