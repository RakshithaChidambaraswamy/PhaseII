package day2;

public class enhancedfordemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int arr1[] = {23,45};

		int arr2[] = new int[] {54, 65};

		int[] arr3= new int[3];
		arr3[0]= 32;
		arr3[1]= 11;
		arr3[2]= 33;
		
		for (int a:arr3)
		{
			System.out.println(a);
		}
	}

}
