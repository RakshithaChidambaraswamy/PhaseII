package day2;

import java.util.Scanner;
public class Contructsdemo {
	
	public static void main(String [] args)
	{
		
		//scanner demo
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the details");
		int a=scan.nextInt();
		String s=scan.next();
		byte b=scan.nextByte();
		
		System.out.println("interger"+a);
		System.out.println("String"+s);
		System.out.println("byte"+b);
		
	}

}
