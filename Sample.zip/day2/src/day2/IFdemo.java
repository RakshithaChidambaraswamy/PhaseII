package day2;

import java.util.Scanner;

public class IFdemo {
	
	public static void main(String args[])
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the value");
		
		int a=scan.nextInt();
		
		if (a>0)
			
		{
			
			System.out.println("Positive");
			
		}
		else if (a<0)
		{	
			System.out.println("negative");
		}
		
		else 
			
		{
			System.out.println("zero");
	}

}
}
