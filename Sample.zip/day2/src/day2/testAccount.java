package day2;

public class testAccount {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		accountClassdemo acc = new accountClassdemo();
		
		accountClassdemo acc1 = new accountClassdemo(100, "SB");
		accountClassdemo.displaydetails;
		
	}

}
