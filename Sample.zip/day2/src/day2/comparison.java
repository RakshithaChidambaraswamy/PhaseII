package day2;

import java.util.Scanner;

public class comparison {

	public static void main(String args[])
	{
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter the value");
		int a=scan.nextInt();
		
		System.out.println("enter second value");
		int b=scan.nextInt();
		
		System.out.println("enter third value");
		int c=scan.nextInt();
		
		
		if (a>=b && a>=c)
			
		{
			if(a==b && a==c){
				System.out.println("allvalues are equal");
			}
			
			else if(a==b){
				System.out.println("a and b are eqaul");
				
			}
			
			else if(a==c)
			{
				System.out.println("a and c are equal");
			}
			else {
			System.out.println("First value is greater");
			
			}
		}
		else if (b>=c)
		{
			if(b==c)
			{
				System.out.println("b and c are equal");	
			}
		
				
			else
			
		{
			System.out.println("second value is bigger");
		}
			
		}
		
		else 
	}

}

