package practise;

import java.util.Scanner;

public class Areaofcircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner side = new Scanner(System.in);
System.out.println("enter the radius of the circle");
double s= side.nextDouble();
double area = (22*s*s)/7;
System.out.println("Are of circle is "+area);
	}

}
